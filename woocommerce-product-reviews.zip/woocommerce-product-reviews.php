<?php
/**
 * Plugin Name: WooCommerce Product Reviews
 * Plugin URI:  https://github.com/webman-technologies/woocommerce-product-reviews
 * Description: SEO-friendly WooCommerce Product Reviews plugin – custom review titles, clean display, translation-ready, easy to extend.
 * Version:     1.0.0
 * Author:      Webman Technologies
 * Author URI:  https://webman-technologies.com
 * Text Domain: woocommerce-product-reviews
 * Domain Path: /languages
 */
if ( ! defined( 'ABSPATH' ) ) exit;
require_once plugin_dir_path( __FILE__ ) . 'includes/class-wc-pr-main.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/functions.php';
add_action( 'plugins_loaded', array( 'WC_PR_Main', 'get_instance' ) );
?>