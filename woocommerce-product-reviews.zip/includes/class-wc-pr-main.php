<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class WC_PR_Main {
    private static $instance = null;
    public static function get_instance() {
        if ( null == self::$instance ) self::$instance = new self();
        return self::$instance;
    }
    public function __construct() {
        add_action( 'init', array( $this, 'load_textdomain' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_filter( 'woocommerce_product_review_comment_form_args', array( $this, 'custom_review_form' ) );
        add_filter( 'woocommerce_review_before_comment_meta', array( $this, 'display_review_data' ) );
    }
    public function load_textdomain() {
        load_plugin_textdomain( 'woocommerce-product-reviews', false, dirname( plugin_basename( __FILE__ ) ) . '/../languages' );
    }
    public function enqueue_assets() {
        wp_enqueue_style( 'wc-pr-style', plugin_dir_url( __FILE__ ) . '../assets/css/style.css', array(), '1.0.0' );
        wp_enqueue_script( 'wc-pr-script', plugin_dir_url( __FILE__ ) . '../assets/js/script.js', array('jquery'), '1.0.0', true );
    }
    public function custom_review_form( $comment_form ) {
        $comment_form['fields']['review_title'] = '<p class="comment-form-review-title"><label for="review_title">' . __( 'Review Title', 'woocommerce-product-reviews' ) . '</label><input id="review_title" name="review_title" type="text" size="30" /></p>';
        return $comment_form;
    }
    public function display_review_data() {
        global $comment;
        $review_title = get_comment_meta( $comment->comment_ID, 'review_title', true );
        if ( $review_title ) echo '<strong class="review-title">' . esc_html( $review_title ) . '</strong>';
    }
}