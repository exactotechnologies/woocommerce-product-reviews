<?php
if ( ! defined( 'ABSPATH' ) ) exit;
add_action( 'comment_post', 'wc_pr_save_review_meta', 20, 2 );
function wc_pr_save_review_meta( $comment_id, $comment_approved ) {
    if ( isset( $_POST['review_title'] ) && ! empty( $_POST['review_title'] ) )
        add_comment_meta( $comment_id, 'review_title', sanitize_text_field( $_POST['review_title'] ), true );
}
?>